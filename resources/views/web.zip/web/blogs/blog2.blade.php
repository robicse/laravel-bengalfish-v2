<!-- Site Content -->
<section class="blog-content">
<div class="container">

 <div class="blog-area">

   <div class="row">

     <div class="col-12 col-lg-8">
         <div class="row">
             <div class="col-12 col-sm-12">
                 <div class="blog">
                   <div class="blog-thumbnail">
                     <img class="img-thumbnail" src="images/blogs/blog_post_1.jpg" width="100%">

                   </div>


                   <h6 class="blog-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                       ut labore et dolore magna aliqua. <br>
                     <small>Categories: News , Relax , Fashion </small>
                     </h6>
                       <p>
                           Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, voluptatem.
                       </p>
                       <div class="col-12 blog-control">


                                 <div class="row justify-content-between align-items-center">
                                     <div class="col-6 col-sm-6">
                                         18th October
                                     </div>
                                     <div class="col-auto">
                                         <button type="button" class="btn btn-primary"><i class="fab fa-facebook-f"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-twitter"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-instagram"></i></button>
         <button type="button" class="btn btn-primary"><i class="fas fa-envelope"></i></button>
                                                   </div>
                                                 </div>


                                     </div>
                               </div>
                           </div>
                           <div class="col-12 col-sm-12">
                               <div class="blog">
                                 <div class="blog-thumbnail">
                                   <img class="img-thumbnail" src="images/blogs/blog_post_2.jpg" width="100%">

                                 </div>


                                 <h6 class="blog-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                     ut labore et dolore magna aliqua. <br>
                                   <small>Categories: News , Relax , Fashion </small>
                                   </h6>
                                     <p>
                                         Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, voluptatem.
                                     </p>
                                     <div class="col-12 blog-control">


                                               <div class="row justify-content-between align-items-center">
                                                   <div class="col-6 col-sm-6">
                                                       18th October
                                                   </div>
                                                   <div class="col-auto">
                                                       <button type="button" class="btn btn-primary"><i class="fab fa-facebook-f"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-twitter"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-instagram"></i></button>
         <button type="button" class="btn btn-primary"><i class="fas fa-envelope"></i></button>
                                                   </div>
                                                 </div>


                                     </div>
                               </div>
                           </div>
                           <div class="col-12 col-sm-12">
                               <div class="blog">
                                 <div class="blog-thumbnail">
                                   <img class="img-thumbnail" src="images/blogs/blog_post_3.jpg" width="100%">

                                 </div>


                                 <h6 class="blog-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                     ut labore et dolore magna aliqua. <br>
                                   <small>Categories: News , Relax , Fashion </small>
                                   </h6>
                                     <p>
                                         Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, voluptatem.
                                     </p>
                                     <div class="col-12 blog-control">


                                               <div class="row justify-content-between align-items-center">
                                                   <div class="col-6 col-sm-6">
                                                       18th October
                                                   </div>
                                                   <div class="col-auto">
                                                       <button type="button" class="btn btn-primary"><i class="fab fa-facebook-f"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-twitter"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-instagram"></i></button>
         <button type="button" class="btn btn-primary"><i class="fas fa-envelope"></i></button>
                                                   </div>
                                                 </div>


                                     </div>
                               </div>
                           </div>
                           <div class="col-12 col-sm-12">
                               <div class="blog">
                                 <div class="blog-thumbnail">
                                   <img class="img-thumbnail" src="images/blogs/blog_post_4.jpg" width="100%">

                                 </div>


                                 <h6 class="blog-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                     ut labore et dolore magna aliqua. <br>
                                   <small>Categories: News , Relax , Fashion </small>
                                   </h6>
                                     <p>
                                         Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, voluptatem.
                                     </p>
                                     <div class="col-12 blog-control">


                                               <div class="row justify-content-between align-items-center">
                                                   <div class="col-6 col-sm-6">
                                                       18th October
                                                   </div>
                                                   <div class="col-auto">
                                                       <button type="button" class="btn btn-primary"><i class="fab fa-facebook-f"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-twitter"></i></button>
         <button type="button" class="btn btn-primary"><i class="fab fa-instagram"></i></button>
         <button type="button" class="btn btn-primary"><i class="fas fa-envelope"></i></button>
                                                   </div>
                                                 </div>


                                     </div>
                               </div>
                           </div>
                           <div class="col-12">
                               <div class="pagination justify-content-between ">

                                   <label for="staticEmail" class="col-form-label">Showing 1&ndash;<span class="showing_record">1</span>&nbsp;of&nbsp;<span class="showing_total_record">23</span>&nbsp;results.</label>
                               <div class="col-12 col-sm-6">
                                   <ol class="loader-page">
                                     <li class="loader-page-item"><a href="index.html">
                                       <i class="fa fa-angle-double-left" style="font-size:12px"></i></a>
                                     </li>
                                     <li  class="loader-page-item"><a href="#">1</a></li>
                                     <li  class="loader-page-item"><a href="#">2</a></li>
                                     <li  class="loader-page-item"><a href="#">3</a></li>
                                     <li  class="loader-page-item"><a href="#">4</a></li>
                                     <li  class="loader-page-item"><a href="#">
                                       <i class="fa fa-angle-double-right" style="font-size:12px"></i></a>
                                     </li>
                                   </ol>
                               </div>
                                 </div>
                             </div>
                       </div>
                     </div>


                     <div class="col-12 col-lg-4  d-lg-block d-xl-block blog-menu">
                       <div class="category-div">
                           <div class="heading">
                               <h2>
                                CATEGORIES
                               </h2>
                               <hr style="margin-bottom: 0;">
                             </div>
                           <a class=" main-manu btn" data-toggle="collapse" href="#men-cloth" role="button" aria-expanded="false" aria-controls="men-cloth">
                               <img class="img-fuild" src="images/category_icon/1stNav.png">
                                   Men's Clothing <span><i class="fas fa-minus"></i></span>

                             </a>
                             <div class="sub-manu collapse multi-collapse" id="men-cloth">
                               <ul class="unorder-list">
                                   <li class="list-item">
                                     <a class="btn" href="#">
                                         <i class="fas fa-angle-right"></i>Men Polo shirts
                                     </a>
                                     <a class="btn" href="#">
                                         <i class="fas fa-angle-right"></i> Men Jeans
                                       </a>

                                     <a class="btn " href="#">
                                         <i class="fas fa-angle-right"></i> Men Shoes
                                     </a>
                                     <a class="btn" href="#">
                                         <i class="fas fa-angle-right"></i>Sunglasses & Glasses
                                     </a>
                                   </li>
                               </ul>
                             </div>

                             <a class=" main-manu btn" data-toggle="collapse" href="#women-cloth" role="button" aria-expanded="false" aria-controls="women-cloth">
                                 <img class="img-fuild" src="images/category_icon/2ndNav.png">
                                 Women's Clothing  <span><i class="fas fa-minus"></i></span>

                               </a>
                               <div class="sub-manu collapse multi-collapse" id="women-cloth">
                                 <ul class="unorder-list">
                                     <li class="list-item">
                                       <a class="btn" href="#">
                                           <i class="fas fa-angle-right"></i>Women Dresses
                                       </a>
                                       <a class="btn" href="#">
                                           <i class="fas fa-angle-right"></i>Women Shirts & Tops
                                         </a>

                                       <a class="btn" href="#">
                                           <i class="fas fa-angle-right"></i>Women Jeans
                                       </a>
                                       <a class="btn" href="#">
                                           <i class="fas fa-angle-right"></i> Women Hand Bags
                                       </a>
                                     </li>
                                 </ul>
                               </div>

                                 <a class=" main-manu btn" data-toggle="collapse" href="#girl-cloth" role="button" aria-expanded="false" aria-controls="girl-cloth">
                                     <img class="img-fuild" src="images/category_icon/4thNav.png">
                                     Girl's Clothing   <span><i class="fas fa-minus"></i></span>

                                 </a>
                                 <div class="sub-manu collapse multi-collapse" id="girl-cloth">
                                   <ul class="unorder-list">
                                       <li class="list-item">
                                         <a class="btn " href="#">
                                             <i class="fas fa-angle-right"></i>Dresses & Rompers
                                         </a>
                                         <a class="btn " href="#">
                                             <i class="fas fa-angle-right"></i>Shorts & Skirts
                                           </a>

                                         <a class="btn " href="#">
                                             <i class="fas fa-angle-right"></i> Sweaters
                                         </a>

                                       </li>
                                   </ul>
                                 </div>

                                 <a class=" main-manu btn" data-toggle="collapse" href="#household" role="button" aria-expanded="false" aria-controls="household">
                                     <img class="img-fuild" src="images/category_icon/6thNav.png">
                                   Household Merchandises  <span><i class="fas fa-minus"></i></span>

                                 </a>
                                 <div class="sub-manu collapse multi-collapse" id="household">
                                   <ul class="unorder-list">
                                       <li class="list-item">
                                         <a class="btn" href="#">
                                             <i class="fas fa-angle-right"></i>  Bedding Collections
                                         </a>
                                         <a class="btn" href="#">
                                             <i class="fas fa-angle-right"></i> Throws & Pillows
                                           </a>

                                         <a class="btn" href="#">
                                             <i class="fas fa-angle-right"></i>Bath Robes
                                         </a>

                                       </li>
                                   </ul>
                                 </div>
                       </div>
                       <div class="category-div">
                           <div class="heading">
                               <h2>
                                RECENTS POSTS
                               </h2>
                               <hr style="margin-bottom: 0;">
                             </div>
                             <div class="media">
                                 <img src="images/blogs/Recent-posts-image1.jpg" alt="John Doe" class=" mt-1" style="width:68px;height:68px;">
                                 <div class="media-body">
                                   <h4>Lorem ipsum Dolor sit</h4>
                                   <p>Lorem ipsum dolor sit amet,
                                     consectetur adipiscing elit,
                                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                 </div>
                               </div>
                               <div class="media">
                                   <img src="images/blogs/Recent-posts-image2.jpg" alt="John Doe" class=" mt-1" style="width:68px;height:68px;">
                                   <div class="media-body">
                                     <h4>Lorem ipsum Dolor sit</h4>
                                     <p>Lorem ipsum dolor sit amet,
                                       consectetur adipiscing elit,
                                       sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                   </div>
                                 </div>

                                 <div class="media">
                                     <img src="images/blogs/Recent-posts-image3.jpg" alt="John Doe" class=" mt-1" style="width:68px;height:68px;">
                                     <div class="media-body">
                                       <h4>Lorem ipsum Dolor sit</h4>
                                       <p>Lorem ipsum dolor sit amet,
                                         consectetur adipiscing elit,
                                         sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                     </div>
                                   </div>


                       </div>

                       <div class="category-div">
                           <div class="heading">
                               <h2>
                                STAY CONNECTED
                               </h2>
                               <hr style="margin-bottom: 0;">
                             </div>
                           <ul>
                             <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                             <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                             <li><a href="#"><i class="fab fa-skype"></i></a></li>
                             <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                             <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                             </ul>
                       </div>

                       <div class="category-div">
                           <div class="heading">
                               <h2>
                                LATEST COMMENTS
                               </h2>
                               <hr style="margin-bottom: 0;">
                             </div>
                             <div class="media">
                                 <i class="fas fa-comments mt-1"  style="width:68px;height:68px;    font-size: 50px;
                                 text-align: center;"></i>
                                 <div class="media-body">
                                   <p>Lorem ipsum dolor sit amet,
                                     consectetur adipiscing elit,
                                     sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                     <p><span><i class="far fa-clock"></i></span>Dec,25,2019</p>
                                 </div>
                               </div>
                               <div class="media">
                                   <i class="fas fa-comments mt-1"  style="width:68px;height:68px;    font-size: 50px;
                                   text-align: center;"></i>
                                   <div class="media-body">
                                     <p>Lorem ipsum dolor sit amet,
                                       consectetur adipiscing elit,
                                       sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                       <p><span><i class="far fa-clock"></i></span>Dec,25,2019</p>
                                   </div>
                                 </div>
                                 <div class="media">
                                     <i class="fas fa-comments mt-1"  style="width:68px;height:68px;    font-size: 50px;
                                     text-align: center;"></i>
                                     <div class="media-body">
                                       <p>Lorem ipsum dolor sit amet,
                                         consectetur adipiscing elit,
                                         sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                         <p><span><i class="far fa-clock"></i></span>Dec,25,2019</p>
                                     </div>
                                   </div>

                       </div>
                     </div>
                   </div>

                 </div>

               </div>
             </div>
</section>
